import java.util.Scanner;

public class Ejercicio_2 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double analisis, diseno, codificacion, avance;
        int errores;
        String documentacion, exposicion;

        double promedio, ajustes, notaFinal;
        String estado, observacion;

        do {
            System.out.print("Ingrese nota de analisis (0-10): ");
            analisis = sc.nextDouble();

            System.out.print("Ingrese nota de diseno (0-10): ");
            diseno = sc.nextDouble();

            System.out.print("Ingrese nota de codificacion (0-10): ");
            codificacion = sc.nextDouble();

            if (analisis < 0 || analisis > 10 ||
                diseno < 0 || diseno > 10 ||
                codificacion < 0 || codificacion > 10) {

                System.out.println("Las notas deben estar entre 0 y 10.");
            }

        } while (analisis < 0 || analisis > 10 ||
                 diseno < 0 || diseno > 10 ||
                 codificacion < 0 || codificacion > 10);

        System.out.print("Ingrese porcentaje de avance real: ");
        avance = sc.nextDouble();

        System.out.print("Ingrese numero de errores: ");
        errores = sc.nextInt();

        System.out.print("Presento documentacion completa (Si/No): ");
        documentacion = sc.next();

        System.out.print("Realizo exposicion final (Si/No): ");
        exposicion = sc.next();

        promedio = (analisis + diseno + codificacion) / 3;

        ajustes = errores * -0.5;

        if (documentacion.equalsIgnoreCase("Si")) {
            ajustes += 0.5;
        }

        if (exposicion.equalsIgnoreCase("Si")) {
            ajustes += 0.5;
        }

        notaFinal = promedio + ajustes;

        if (notaFinal > 10) {
            notaFinal = 10;
        }

        if (notaFinal < 0) {
            notaFinal = 0;
        }

        if (notaFinal >= 9) {
            estado = "Excelente";
        } else if (notaFinal >= 7) {
            estado = "Aprobado";
        } else if (notaFinal >= 5) {
            estado = "Recuperacion";
        } else {
            estado = "Reprobado";
        }

        if (avance < 60 && estado.equals("Excelente")) {
            estado = "Aprobado";
        }

        observacion = "Sin observaciones";

        if (notaFinal >= 7 && documentacion.equalsIgnoreCase("No")) {
            observacion = "Buen producto, pero mala formalidad";
        }

        System.out.println("\n--- RESULTADOS ---");
        System.out.println("Promedio tecnico: " + promedio);
        System.out.println("Ajustes aplicados: " + ajustes);
        System.out.println("Nota final: " + notaFinal);
        System.out.println("Estado: " + estado);
        System.out.println("Observacion: " + observacion);

        sc.close();
    }
}