import java.util.Scanner;

public class Ejercicio_1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double reto1, reto2, reto3, tiempo;
        int errores;
        String extra, copia;

        double puntajeBase, penalizacion, bonificacion, puntajeFinal;
        String nivel, observacion;

        System.out.print("Ingrese puntaje del reto 1: ");
        reto1 = sc.nextDouble();

        System.out.print("Ingrese puntaje del reto 2: ");
        reto2 = sc.nextDouble();

        System.out.print("Ingrese puntaje del reto 3: ");
        reto3 = sc.nextDouble();

        System.out.print("Ingrese numero de errores: ");
        errores = sc.nextInt();

        System.out.print("Ingrese tiempo total en minutos: ");
        tiempo = sc.nextDouble();

        System.out.print("Resolvio el desafio extra (Si/No): ");
        extra = sc.next();

        System.out.print("Fue descalificado por copia (Si/No): ");
        copia = sc.next();

        puntajeBase = reto1 + reto2 + reto3;

        penalizacion = errores * 4;

        bonificacion = 0;

        if (extra.equalsIgnoreCase("Si")) {
            bonificacion += 15;
        }

        if (tiempo < 30) {
            bonificacion += 10;
        }

        puntajeFinal = puntajeBase - penalizacion + bonificacion;

        if (puntajeFinal < 0) {
            puntajeFinal = 0;
        }

        if (puntajeFinal < 30) {
            nivel = "Principiante";
        } else if (puntajeFinal < 50) {
            nivel = "Basico";
        } else if (puntajeFinal < 70) {
            nivel = "Intermedio";
        } else if (puntajeFinal < 90) {
            nivel = "Avanzado";
        } else {
            nivel = "Experto";
        }

        if (copia.equalsIgnoreCase("Si")) {
            nivel = "Descalificado";
        }

        observacion = "Sin observaciones";

        if (puntajeFinal >= 70 && errores >= 5) {
            observacion = "Resultado inconsistente: revisar calidad de resolucion";
        }

        System.out.println("\n--- RESULTADOS ---");
        System.out.println("Puntaje base: " + puntajeBase);
        System.out.println("Penalizacion: " + penalizacion);
        System.out.println("Bonificacion: " + bonificacion);
        System.out.println("Puntaje final: " + puntajeFinal);
        System.out.println("Nivel: " + nivel);
        System.out.println("Observacion: " + observacion);

        sc.close();
    }
}